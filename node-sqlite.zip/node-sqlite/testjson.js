var LTT = require('list-to-tree');
    var list = [ 
    { id: 1, title: 'Title 1', parent: 0 },
    { id: 2, title: 'Title 2', parent: 1 },
    { id: 3, title: 'Title 3', parent: 2 },
    { id: 4, title: 'Title 4', parent: 0 } 
    ];
 
    var ltt = new LTT(list, {
        key_id: 'id',
        key_parent: 'parent',
        key_child: 'children'
    });
    var tree = ltt.GetTree();
 
    console.log( JSON.stringify(tree) );