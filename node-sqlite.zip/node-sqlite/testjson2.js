let arr = {1:{'id':1, 'parent_id':0}, 2:{'id':2, 'parent_id':1}, 3:{'id':3, 'parent_id':1}}
let arr2 = arr
//console.log(arr[0][1]['parent_id'])
//arr[0]['child'] = new Array()
//arr[0]['child'][arr[1]['id']] = arr[1]
//arr[0]['child'][arr[2]['id']] = arr[2]
//console.log(arr)

function arrProc(space, arr) {
	 
	//console.log(space)
	for (var key in arr) {
		console.log(key)
		var parent_id = arr[key]['parent_id']
		if (parent_id > 0) {
			//console.log(arr[parent_id]['id'])
			var count = key
			arr[parent_id]['child'] = []
			arr[parent_id]['child'].push(arr[key])
		}
		
		//if (arr[key]['parent_id'] > 0) {
		//	arrProc2(arr[key]['parent_id'], arr[key])	
		//}
	}
	//
	console.log(arr)
}

/*function arrProc2(id, childObj) {
	let i
	for (var key in arr2) {
		//console.log(arr[key]['parent_id'])
		if (arr[key]['id'] == id) {
			arr[key].child = new Object
			arr[key].child[childObj['id']] = [childObj]
			//console.log(childObj['id'])
			return
		}
	}
}*/

arrProc('', arr)