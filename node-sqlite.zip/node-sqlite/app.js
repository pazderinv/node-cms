const sqlite3 = require('sqlite3')

let db = new sqlite3.Database("./mydb.sqlite3", (err) => { 
    if (err) { 
        console.log('Error when creating the database', err) 
    } else { 
        console.log('Database created!') 
        /* Put code to create table(s) here */
        //createTable()
        readTable()
        //insertData();
    } 
})

const createTable = () => {
    console.log("create database table contacts");
    //db.run("CREATE TABLE IF NOT EXISTS contacts(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT)",  insertData);
    db.run("CREATE TABLE IF NOT EXISTS cat(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, parent INTEGER)",  insertData);    
}

const insertData = () =>{
    console.log("Insert data")
    //db.run('INSERT INTO contacts (name) VALUES (?)', ["contact 002"]);
    db.run('INSERT INTO cat (title, parent) VALUES (?, ?)', ["Title 1", 0]);
    db.run('INSERT INTO cat (title, parent) VALUES (?, ?)', ["Title 2", 1]);
    db.run('INSERT INTO cat (title, parent) VALUES (?, ?)', ["Title 3", 2]);
    db.run('INSERT INTO cat (title, parent) VALUES (?, ?)', ["Title 4", 0]);
}

const readTable = () => {
    console.log("Read data from contacts");
    //db.all("SELECT rowid AS id, name FROM contacts", function(err, rows) {
    db.all("SELECT * FROM cat", function(err, rows) {
        var arr = []
        rows.forEach(function (row) {
            
            arr.push(row)
            //console.log(row);
            //console.log(row.id + ": " + row.name);
        });
        console.log(arr)
        //console.log(JSON.stringify(arr))
    });
}

db.close();